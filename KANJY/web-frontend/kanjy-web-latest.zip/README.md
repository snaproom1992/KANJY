# KANJY Web Frontend

KANJYアプリのスケジュール調整機能のWebフロントエンドです。

## 🚀 本番ファイル

### 必要なファイル
- `index.html` - メインページ（スケジュール表示）
- `response-form.html` - 回答フォーム
- `assets/App icon.png` - アプリアイコン
- `netlify.toml` - デプロイ設定

## 📁 ディレクトリ構成

```
web-frontend/
├── index.html              # メインページ
├── response-form.html      # 回答フォーム
├── assets/                 # 画像ファイル
│   └── App icon.png
├── netlify.toml           # デプロイ設定
├── archive/               # 開発中のファイル（不要）
├── development-files/     # 開発ドキュメント（不要）
└── README.md             # このファイル
```

## 🔗 アプリとの連携

### URL形式
```
メインページ: https://your-domain.com/index.html?id={eventId}&t={timestamp}
回答フォーム: https://your-domain.com/response-form.html?id={eventId}
```

### SwiftUIからの呼び出し例
```swift
struct ScheduleWebView: View {
    let eventId: String
    
    var body: some View {
        WebView(url: URL(string: "https://your-domain.com/index.html?id=\(eventId)&t=\(Int(Date().timeIntervalSince1970))")!)
            .navigationTitle("スケジュール調整")
            .navigationBarTitleDisplayMode(.inline)
    }
}
```

## 🌐 デプロイ方法

### Netlify（推奨）
1. web-frontendフォルダをNetlifyにドラッグ&ドロップ
2. 自動デプロイ完了

### 他のホスティングサービス
- Vercel
- Firebase Hosting
- GitHub Pages

## 🔧 開発サーバー

```bash
cd web-frontend
python3 -m http.server 3003
```

アクセス: `http://localhost:3003/index.html?id=test&t=1234567890`

## 📋 機能一覧

### メインページ（index.html）
- ✅ 日程別回答状況表
- ✅ 詳細回答一覧
- ✅ 統計情報
- ✅ URLシェア機能
- ✅ App Storeリンク

### 回答フォーム（response-form.html）
- ✅ 新規回答作成
- ✅ 既存回答編集
- ✅ 回答削除
- ✅ カスタム通知システム
- ✅ カスタム確認ダイアログ

## 🎨 技術仕様

- **フレームワーク**: Vanilla HTML/CSS/JavaScript
- **スタイリング**: Tailwind CSS (CDN)
- **データベース**: Supabase
- **フォント**: Inter
- **アイコン**: Heroicons
- **レスポンシブ**: 完全対応

## 📞 サポート

お問い合わせ: snaproom.info@gmail.com 