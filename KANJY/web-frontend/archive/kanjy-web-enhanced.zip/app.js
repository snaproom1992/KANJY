// Supabase設定
const SUPABASE_URL = 'https://jvluhjifihiuopqdwjll.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp2bHVoamlmaWhpdW9wcWR3amxsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTExNTc5OTEsImV4cCI6MjA2NjczMzk5MX0.WDTzIs73X8NHGFcIYFk4CN-7dH5tQT5l0Bd2uY6H9lc';

// Supabaseクライアント初期化
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// グローバル変数
let currentEvent = null;
let currentEventId = null;

// ページ読み込み時の処理
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // URLからイベントIDを取得
        const urlParams = new URLSearchParams(window.location.search);
        const eventId = urlParams.get('id');
        
        if (!eventId) {
            throw new Error('イベントIDが指定されていません');
        }
        
        currentEventId = eventId;
        
        // イベント情報を取得
        await loadEvent(eventId);
        
        // リアルタイム購読を開始
        subscribeToRealtime();
        
        // フォームイベントを設定
        setupFormEvents();
        
        // ローディング画面を非表示
        hideLoading();
        
    } catch (error) {
        console.error('初期化エラー:', error);
        showError(error.message);
    }
});

// イベント情報を読み込み
async function loadEvent(eventId) {
    try {
        console.log('イベントID:', eventId);
        
        const { data: events, error } = await supabase
            .from('events')
            .select('*')
            .eq('id', eventId);
        
        console.log('Supabaseレスポンス:', { data: events, error });
        
        if (error) throw error;
        if (!events || events.length === 0) throw new Error('イベントが見つかりません');
        if (events.length > 1) throw new Error('複数のイベントが見つかりました');
        
        const event = events[0];
        
        currentEvent = event;
        displayEvent(event);
        await loadResponses(eventId);
        
    } catch (error) {
        console.error('イベント読み込みエラー:', error);
        console.error('エラー詳細:', error.message);
        throw error;
    }
}

// イベント情報を表示
function displayEvent(event) {
    // タイトルと説明
    document.getElementById('event-title').textContent = event.title;
    if (event.description) {
        document.getElementById('event-description').textContent = event.description;
    } else {
        document.getElementById('event-description').style.display = 'none';
    }
    
    // 場所
    if (event.location) {
        document.getElementById('location-text').textContent = event.location;
    } else {
        document.getElementById('location-info').style.display = 'none';
    }
    
    // 予算
    if (event.budget) {
        document.getElementById('budget-text').textContent = `¥${event.budget.toLocaleString()}`;
    } else {
        document.getElementById('budget-info').style.display = 'none';
    }
    
    // 回答期限
    if (event.deadline) {
        const deadline = new Date(event.deadline);
        const now = new Date();
        const isExpired = deadline < now;
        
        document.getElementById('deadline-text').textContent = 
            `${formatDateTime(deadline)} ${isExpired ? '(期限切れ)' : ''}`;
        
        if (isExpired) {
            document.getElementById('deadline-info').style.color = '#dc3545';
        }
    } else {
        document.getElementById('deadline-info').style.display = 'none';
    }
    
    // 候補日時
    displayCandidateDates(event.candidate_dates);
}

// 候補日時を表示
function displayCandidateDates(dates) {
    const datesGrid = document.getElementById('dates-grid');
    const checkboxesContainer = document.getElementById('available-dates-checkboxes');
    
    datesGrid.innerHTML = '';
    checkboxesContainer.innerHTML = '';
    
    dates.forEach(date => {
        const dateObj = new Date(date);
        
        // 候補日時表示
        const dateItem = document.createElement('div');
        dateItem.className = 'date-item fade-in';
        dateItem.innerHTML = `
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <span style="font-size: 1.2rem;">📅</span>
                <span>${formatDateTime(dateObj)}</span>
            </div>
        `;
        datesGrid.appendChild(dateItem);
        
        // チェックボックス
        const checkboxItem = document.createElement('label');
        checkboxItem.className = 'checkbox-item';
        checkboxItem.innerHTML = `
            <input type="checkbox" value="${date}" name="available_dates">
            <span>${formatDateTime(dateObj)}</span>
        `;
        checkboxesContainer.appendChild(checkboxItem);
    });
}

// 回答を読み込み
async function loadResponses(eventId) {
    try {
        const { data: responses, error } = await supabase
            .from('responses')
            .select('*')
            .eq('event_id', eventId)
            .order('created_at', { ascending: false });
        
        if (error) throw error;
        
        displayResponses(responses || []);
        
    } catch (error) {
        console.error('回答読み込みエラー:', error);
    }
}

// 回答を表示
function displayResponses(responses) {
    const container = document.getElementById('responses-container');
    
    if (responses.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #666; padding: 2rem;">まだ回答がありません</p>';
        return;
    }
    
    // 回答サマリーを表示
    displayResponseSummary(responses);
    
    container.innerHTML = '';
    
    responses.forEach(response => {
        const responseItem = document.createElement('div');
        responseItem.className = `response-item ${response.status} fade-in`;
        
        const availableDatesText = response.available_dates && response.available_dates.length > 0
            ? response.available_dates.map(date => formatDateTime(new Date(date))).join(', ')
            : 'なし';
        
        responseItem.innerHTML = `
            <div class="response-header">
                <div>
                    <span class="participant-name">${response.participant_name}</span>
                    ${response.department ? `<span style="color: #666; font-size: 0.9rem;"> (${response.department})</span>` : ''}
                </div>
                <span class="status-badge ${response.status}">${getStatusText(response.status)}</span>
            </div>
            <div class="response-details">
                ${response.available_dates && response.available_dates.length > 0 
                    ? `<p><strong>参加可能日時:</strong> ${availableDatesText}</p>` : ''}
                ${response.comment ? `<p><strong>コメント:</strong> ${response.comment}</p>` : ''}
                <p><strong>回答日時:</strong> ${formatDateTime(new Date(response.response_date))}</p>
            </div>
        `;
        
        container.appendChild(responseItem);
    });
}

// 回答サマリーを表示
function displayResponseSummary(responses) {
    // 候補日時ごとの参加者数を集計
    const dateCounts = {};
    currentEvent.candidate_dates.forEach(dateStr => {
        dateCounts[dateStr] = {
            attending: 0,
            total: responses.length
        };
    });
    
    responses.forEach(response => {
        if (response.status === 'attending' && response.available_dates) {
            response.available_dates.forEach(dateStr => {
                if (dateCounts[dateStr]) {
                    dateCounts[dateStr].attending++;
                }
            });
        }
    });
    
    // サマリー表示エリアを更新
    const summaryContainer = document.getElementById('response-summary');
    if (!summaryContainer) {
        // サマリー表示エリアを作成
        const summaryDiv = document.createElement('div');
        summaryDiv.id = 'response-summary';
        summaryDiv.className = 'response-summary';
        
        const responsesSection = document.querySelector('.responses-list');
        responsesSection.insertBefore(summaryDiv, document.getElementById('responses-container'));
    }
    
    const summaryHtml = `
        <h3>📊 参加状況サマリー</h3>
        <div class="summary-grid">
            ${Object.entries(dateCounts).map(([dateStr, counts]) => `
                <div class="summary-item">
                    <div class="summary-date">${formatDateTime(new Date(dateStr))}</div>
                    <div class="summary-count">
                        <span class="attending-count">${counts.attending}人参加</span>
                        <span class="total-count">/ 回答者${counts.total}人</span>
                    </div>
                </div>
            `).join('')}
        </div>
        <div class="total-responses">
            <strong>総回答数: ${responses.length}件</strong>
        </div>
    `;
    
    document.getElementById('response-summary').innerHTML = summaryHtml;
}

// フォームイベントを設定
function setupFormEvents() {
    const form = document.getElementById('response-form');
    const statusRadios = document.querySelectorAll('input[name="status"]');
    const availableDatesGroup = document.getElementById('available-dates-group');
    
    // 参加状況の変更で参加可能日時の表示/非表示を切り替え
    statusRadios.forEach(radio => {
        radio.addEventListener('change', (e) => {
            if (e.target.value === 'attending') {
                availableDatesGroup.style.display = 'block';
            } else {
                availableDatesGroup.style.display = 'none';
                // チェックボックスをクリア
                document.querySelectorAll('input[name="available_dates"]').forEach(cb => cb.checked = false);
            }
        });
    });
    
    // フォーム送信
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const submitBtn = form.querySelector('.submit-btn');
        submitBtn.disabled = true;
        submitBtn.textContent = '送信中...';
        
        try {
            const submittedData = await submitResponse();
            
            // フォームを非表示にして、送信完了メッセージを表示
            form.style.display = 'none';
            showSubmissionSuccess(submittedData);
            
            // 回答一覧を更新
            await loadResponses(currentEventId);
            
        } catch (error) {
            console.error('送信エラー:', error);
            showError('送信に失敗しました。もう一度お試しください。');
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = '回答を送信';
        }
    });
}

// 回答を送信
async function submitResponse() {
    const formData = new FormData(document.getElementById('response-form'));
    
    const participantName = formData.get('participant-name');
    const department = formData.get('department');
    const status = formData.get('status');
    const comment = formData.get('comment');
    
    console.log('フォームデータ確認:');
    console.log('participantName:', participantName);
    console.log('department:', department);
    console.log('status:', status);
    console.log('comment:', comment);
    
    // 参加可能日時を取得
    const availableDates = [];
    document.querySelectorAll('input[name="available_dates"]:checked').forEach(cb => {
        availableDates.push(cb.value);
    });
    
    // バリデーション
    if (!participantName || participantName.trim() === '') {
        throw new Error('お名前を入力してください');
    }
    if (!status) {
        throw new Error('参加状況を選択してください');
    }
    
    const responseData = {
        event_id: currentEventId,
        participant_name: participantName.trim(),
        department: department ? department.trim() : null,
        status: status,
        available_dates: availableDates,
        comment: comment ? comment.trim() : null,
        response_date: new Date().toISOString(),
        created_at: new Date().toISOString()
    };
    
    console.log('送信データ:', responseData);
    
    const { error } = await supabase
        .from('responses')
        .insert([responseData]);
    
    if (error) {
        console.error('Supabaseエラー詳細:', error);
        throw error;
    }
    
    return responseData;
}

// リアルタイム購読を開始
function subscribeToRealtime() {
    // 回答の変更を監視
    supabase
        .channel('responses')
        .on('postgres_changes', 
            { 
                event: '*', 
                schema: 'public', 
                table: 'responses',
                filter: `event_id=eq.${currentEventId}`
            }, 
            (payload) => {
                console.log('リアルタイム更新:', payload);
                loadResponses(currentEventId);
            }
        )
        .subscribe();
}

// ユーティリティ関数
function formatDateTime(date) {
    const options = {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        weekday: 'short',
        hour: '2-digit',
        minute: '2-digit'
    };
    return date.toLocaleDateString('ja-JP', options);
}

function getStatusText(status) {
    const statusMap = {
        'attending': '参加',
        'not_attending': '不参加',
        'undecided': '未定'
    };
    return statusMap[status] || status;
}

function hideLoading() {
    document.getElementById('loading').classList.add('hidden');
    document.getElementById('event-detail').classList.remove('hidden');
}

function showError(message) {
    document.getElementById('loading').classList.add('hidden');
    document.getElementById('event-detail').classList.add('hidden');
    document.getElementById('error').classList.remove('hidden');
    document.getElementById('error-message').textContent = message;
}

function showSuccess(message) {
    // 簡単な成功メッセージを表示
    const successDiv = document.createElement('div');
    successDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #28a745;
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        z-index: 1000;
        animation: slideIn 0.3s ease-out;
    `;
    successDiv.textContent = message;
    document.body.appendChild(successDiv);
    
    setTimeout(() => {
        successDiv.remove();
    }, 3000);
}

// 送信完了メッセージを表示
function showSubmissionSuccess(submittedData) {
    const responseSection = document.querySelector('.response-form');
    const successDiv = document.createElement('div');
    successDiv.className = 'submission-success';
    
    const availableDatesText = submittedData.available_dates && submittedData.available_dates.length > 0
        ? submittedData.available_dates.map(date => formatDateTime(new Date(date))).join(', ')
        : 'なし';
    
    successDiv.innerHTML = `
        <div class="success-header">
            <div class="success-icon">✅</div>
            <h3>回答を送信しました！</h3>
        </div>
        <div class="submitted-response">
            <h4>あなたの回答内容:</h4>
            <div class="response-details">
                <p><strong>お名前:</strong> ${submittedData.participant_name}</p>
                ${submittedData.department ? `<p><strong>部署:</strong> ${submittedData.department}</p>` : ''}
                <p><strong>参加状況:</strong> ${getStatusText(submittedData.status)}</p>
                ${submittedData.available_dates && submittedData.available_dates.length > 0 
                    ? `<p><strong>参加可能日時:</strong> ${availableDatesText}</p>` : ''}
                ${submittedData.comment ? `<p><strong>コメント:</strong> ${submittedData.comment}</p>` : ''}
            </div>
        </div>
        <p class="success-note">回答内容は下記の「回答一覧」で確認できます。</p>
    `;
    
    responseSection.appendChild(successDiv);
}

// 成功メッセージのアニメーション
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
`;
document.head.appendChild(style); 